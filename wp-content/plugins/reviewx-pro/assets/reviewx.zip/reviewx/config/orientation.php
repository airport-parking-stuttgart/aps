<?php

return [
    'plugin_prefix' => 'reviewx',
    'brand_icon' => esc_url(assets('images/ReviewX.svg'))
];