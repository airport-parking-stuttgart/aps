<?php

    $class .= ' rx-colorpicker-field';

?>

<input type="text" id="<?php echo $name; ?>" name="<?php echo $name; ?>" class="<?php echo $class; ?>" value="<?php echo $value; ?>" <?php echo $attrs; ?>/>