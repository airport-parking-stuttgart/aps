<?php
$settings = array( 'media_buttons' => true );
wp_editor( $value, $name, $settings );