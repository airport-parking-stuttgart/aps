<a href="<?php echo get_edit_comment_link($item['id']); ?>" class="actions__btn actions__btn--edit"><?php esc_html_e('Edit', 'reviewx'); ?></a>
