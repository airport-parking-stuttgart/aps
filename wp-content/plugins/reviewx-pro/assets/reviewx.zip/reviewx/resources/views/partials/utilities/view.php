<a href="#" class="rx_modal-toggle actions__btn actions__btn--view"><?php esc_html_e('View', 'reviewx');?></a>
