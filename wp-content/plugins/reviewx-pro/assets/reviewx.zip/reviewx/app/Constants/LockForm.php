<?php

namespace ReviewX\Constants;

interface LockForm
{
    const SETTINGS = "rx_optimistic_settings";
    const QUICK_SETUP = "rx_optimistic_quick_setup";
    const REVIEW_EMAIL = "rx_optimistic_review_email";
}