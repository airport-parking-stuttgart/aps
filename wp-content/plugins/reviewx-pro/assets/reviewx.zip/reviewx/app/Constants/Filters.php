<?php

namespace ReviewX\Constants;

interface Filters
{
    const REVIEWX_ADD_CRITERIA = "reviewx_add_criteria";
    const RX_LOAD_ELEMENTOR_STYLE_CONTROLLER = "rx_load_elementor_style_controller";
    const RX_LOAD_OXYGEN_STYLE_CONTROLLER = "rx_load_oxygen_style_controller";
}