<?php

namespace ReviewX\Constants;

interface Reviewx
{
	const DOMAIN = 'reviewx';
	const DOMAIN_PRO = "reviewx-pro";
}