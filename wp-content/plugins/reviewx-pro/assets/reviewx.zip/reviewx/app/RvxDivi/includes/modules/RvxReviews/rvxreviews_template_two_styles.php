<?php 
$rvx_template_two_filter_background_color	= $this->props['rvx_template_two_filter_background_color'];
$rvx_template_two_filtering_bar_color	= $this->props['rvx_template_two_filtering_bar_color'];
$rvx_template_two_filtering_dropdown_color	= $this->props['rvx_template_two_filtering_dropdown_color'];
$rvx_template_two_filtering_dropdown_text_color	= $this->props['rvx_template_two_filtering_dropdown_text_color'];
$rvx_template_two_filtering_dropdown_selector_color	= $this->props['rvx_template_two_filtering_dropdown_selector_color'];
$rvx_template_two_filtering_dropdown_bar_color	= $this->props['rvx_template_two_filtering_dropdown_bar_color'];
$rvx_template_two_author_text_color	= $this->props['rvx_template_two_author_text_color'];
$rvx_template_two_rating_color	= $this->props['rvx_template_two_rating_color'];
$rvx_template_two_rating_size	= $this->props['rvx_template_two_rating_size'];
$rvx_template_two_title_color	= $this->props['rvx_template_two_title_color'];
$rvx_template_two_text_color	= $this->props['rvx_template_two_text_color'];
$rvx_template_two_attachment_position	= $this->props['rvx_template_two_attachment_position'];
$rvx_template_two_background_color	= $this->props['rvx_template_two_background_color'];
$rvx_template_two_date_color	= $this->props['rvx_template_two_date_color'];
$rvx_template_two_date_icon_color	= $this->props['rvx_template_two_date_icon_color'];
$rvx_template_two_verified_badge_color	= $this->props['rvx_template_two_verified_badge_color'];
$rvx_template_two_verified_badge_icon_color	= $this->props['rvx_template_two_verified_badge_icon_color'];
$rvx_template_two_helpful_text_color	= $this->props['rvx_template_two_helpful_text_color'];
$rvx_template_two_helpful_button_color	= $this->props['rvx_template_two_helpful_button_color'];
$rvx_template_two_helpful_thumbsup_color	= $this->props['rvx_template_two_helpful_thumbsup_color'];
$rvx_template_two_helpful_thumbsup_count_color	= $this->props['rvx_template_two_helpful_thumbsup_count_color'];
$rvx_template_two_share_text_color	= $this->props['rvx_template_two_share_text_color'];
$rvx_template_two_share_icon_color	= $this->props['rvx_template_two_share_icon_color'];
$rvx_template_two_facebook_icon_color	= $this->props['rvx_template_two_facebook_icon_color'];
$rvx_template_two_twitter_icon_color	= $this->props['rvx_template_two_twitter_icon_color'];
$rvx_template_two_highlight_icon_color	= $this->props['rvx_template_two_highlight_icon_color'];
$rvx_template_two_highlight_bg_color	= $this->props['rvx_template_two_highlight_bg_color'];
$rvx_template_two_reply_highlight_bg_color	= $this->props['rvx_template_two_reply_highlight_bg_color'];
$rvx_template_two_pagination_text_color	= $this->props['rvx_template_two_pagination_text_color'];
$rvx_template_two_pagination_bg_color	= $this->props['rvx_template_two_pagination_bg_color'];
$rvx_template_two_pagination_active_color	= $this->props['rvx_template_two_pagination_active_color'];
$rvx_template_two_pagination_active_bg_color	= $this->props['rvx_template_two_pagination_active_bg_color'];
$rvx_template_two_pagination_hover_text_color	= $this->props['rvx_template_two_pagination_hover_text_color'];
$rvx_template_two_pagination_hover_bg_color	= $this->props['rvx_template_two_pagination_hover_bg_color'];

//Store Reply
$rvx_template_two_store_logo_color	= $this->props['rvx_template_two_store_logo_color'];
$rvx_template_two_store_logo_bg_color	= $this->props['rvx_template_two_store_logo_bg_color'];
$rvx_template_two_store_logo_border_radius	= $this->props['rvx_template_two_store_logo_border_radius'];
$rvx_template_two_store_name_color	= $this->props['rvx_template_two_store_name_color'];
$rvx_template_two_store_reply_back_icon_color	= $this->props['rvx_template_two_store_reply_back_icon_color'];
$rvx_template_two_store_reply_text_color	= $this->props['rvx_template_two_store_reply_text_color'];
$rvx_template_two_store_reply_date_color	= $this->props['rvx_template_two_store_reply_date_color'];
$rvx_template_two_store_reply_date_icon_color	= $this->props['rvx_template_two_store_reply_date_icon_color'];
$rvx_template_two_store_reply_date_edit_icon_color	= $this->props['rvx_template_two_store_reply_date_edit_icon_color'];
$rvx_template_two_store_reply_date_delete_icon_color	= $this->props['rvx_template_two_store_reply_date_delete_icon_color'];
$rvx_template_two_store_reply_button_text_color	= $this->props['rvx_template_two_store_reply_button_text_color'];
$rvx_template_two_store_reply_button_bg_color	= $this->props['rvx_template_two_store_reply_button_bg_color'];
$rvx_template_two_store_reply_button_border_color	= $this->props['rvx_template_two_store_reply_button_border_color'];
$rvx_template_two_store_reply_form_bgcolor	= $this->props['rvx_template_two_store_reply_form_bgcolor'];
$rvx_template_two_store_reply_form_border_color	= $this->props['rvx_template_two_store_reply_form_border_color'];
$rvx_template_two_store_reply_form_border_radius	= $this->props['rvx_template_two_store_reply_form_border_radius'];
$rvx_template_two_store_reply_form_title_color	= $this->props['rvx_template_two_store_reply_form_title_color'];
$rvx_template_two_store_reply_form_textarea_bgcolor	= $this->props['rvx_template_two_store_reply_form_textarea_bgcolor'];
$rvx_template_two_store_reply_form_button_color	= $this->props['rvx_template_two_store_reply_form_button_color'];
$rvx_template_two_store_reply_form_button_text_color	= $this->props['rvx_template_two_store_reply_form_button_text_color'];
$rvx_template_two_store_reply_form_cancel_button_bg_color	= $this->props['rvx_template_two_store_reply_form_cancel_button_bg_color'];
$rvx_template_two_store_reply_form_cancel_button_border_color	= $this->props['rvx_template_two_store_reply_form_cancel_button_border_color'];
$rvx_template_two_store_reply_form_cancel_button_text_color	= $this->props['rvx_template_two_store_reply_form_cancel_button_text_color'];

$rvx_template_two_form_rating_type	= $this->props['rvx_template_two_form_rating_type'];
$rvx_template_two_form_rating_color = $this->props['rvx_template_two_form_rating_color'];
$rvx_template_two_form_criteria_color	= $this->props['rvx_template_two_form_criteria_color'];
$rvx_template_two_form_recommendation_label_color	= $this->props['rvx_template_two_form_recommendation_label_color'];
$rvx_template_two_form_icon_active_color	= $this->props['rvx_template_two_form_icon_active_color'];
$rvx_template_two_form_external_video_link_color	= $this->props['rvx_template_two_form_external_video_link_color'];
$rvx_template_two_form_submit_button_text_color	= $this->props['rvx_template_two_form_submit_button_text_color'];
$rvx_template_two_form_submit_button_bg_color	= $this->props['rvx_template_two_form_submit_button_bg_color'];
$rvx_template_two_form_submit_button_border_radius	= $this->props['rvx_template_two_form_submit_button_border_radius'];

/********************************************
 * 
 * Template Two Style
 * 
 *******************************************/

if($rvx_template_two_filter_background_color!=''){
    $echo_template_two_filter_bg_color = '';
    $echo_template_two_filter_bg_color .='background-color:'.$rvx_template_two_filter_background_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-filter-bar-style-2',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_filter_bg_color)),
    ) );		
}

if($rvx_template_two_filtering_bar_color!=''){
    $echo_template_two_filter_color = '';
    $echo_template_two_filter_color .='color:'.$rvx_template_two_filtering_bar_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-filter-bar-style-2 .rx_filter_header h4, .rx-filter-bar-style-2 .rx-short-by h4',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_filter_color)),
    ) );		
}

if($rvx_template_two_filtering_dropdown_color!=''){
    $echo_template_two_dropdown_color = '';
    $echo_template_two_dropdown_color .='background-color:'.$rvx_template_two_filtering_dropdown_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-filter-bar-style-2 .rx_review_shorting_2 .box select',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_dropdown_color)),
    ) );		
}

if($rvx_template_two_filtering_dropdown_text_color!=''){
    $echo_template_two_dropdown_text_color = '';
    $echo_template_two_dropdown_text_color .='color:'.$rvx_template_two_filtering_dropdown_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-filter-bar-style-2 .rx_review_shorting_2 .box select',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_dropdown_text_color)),
    ) );		
}

if($rvx_template_two_filtering_dropdown_selector_color!=''){
    $echo_template_two_dropdown_icon_color = '';
    $echo_template_two_dropdown_icon_color .='border-color:'.$rvx_template_two_filtering_dropdown_selector_color.' transparent transparent transparent !important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-filter-bar-style-2 .rx_review_shorting_2 .box .rx-selection-arrow b',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_dropdown_icon_color)),
    ) );		
}

if($rvx_template_two_filtering_dropdown_bar_color!=''){
    $echo_template_two_dropdown_bar_color = '';
    $echo_template_two_dropdown_bar_color .='background-color:'.$rvx_template_two_filtering_dropdown_bar_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-filter-bar-style-2 .rx_review_shorting_2 .box .rx-selection-arrow',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_dropdown_bar_color)),
    ) );		
}

if($rvx_template_two_author_text_color!=''){
    $echo_template_two_author_text_color = '';
    $echo_template_two_author_text_color .='color:'.$rvx_template_two_author_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_author_info .rx_author_name h4',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_author_text_color)),
    ) );		
}

if($rvx_template_two_rating_color!=''){
    $echo_template_two_rating_color = '';
    $echo_template_two_rating_color .='fill:'.$rvx_template_two_rating_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_review_sort_list .rx_listing_container_style_2 .rx_listing_style_2 .rx_avg_star_color',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_rating_color)),
    ) );		
}

if($rvx_template_two_rating_size!=''){
    $echo_template_two_rating_size = '';
    $echo_template_two_rating_size .='width:'.$rvx_template_two_rating_size.'!important; height:'.$rvx_template_two_rating_size.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .review_rating svg',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_rating_size)),
    ) );		
}

if($rvx_template_two_title_color!=''){
    $echo_template_two_title_color = '';
    $echo_template_two_title_color .='color:'.$rvx_template_two_title_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .review_title',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_title_color)),
    ) );		
}

if($rvx_template_two_text_color!=''){
    $echo_template_two_text_color = '';
    $echo_template_two_text_color .='color:'.$rvx_template_two_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body p',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_text_color)),
    ) );		
}

if($rvx_template_two_attachment_position!=''){
    $echo_template_two_attachment_position = '';
    $echo_template_two_attachment_position .='justify-content:'.$rvx_template_two_attachment_position.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .rx_photos',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_attachment_position)),
    ) );		
}

if($rvx_template_two_date_color!=''){
    $echo_template_two_date_color = '';
    $echo_template_two_date_color .='color:'.$rvx_template_two_date_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .rx_review_calender',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_date_color)),
    ) );		
}

if($rvx_template_two_date_icon_color!=''){
    $echo_template_two_date_icon_color = '';
    $echo_template_two_date_icon_color .='fill:'.$rvx_template_two_date_icon_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .rx_review_calender svg .st0',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_date_icon_color)),
    ) );		
}

if($rvx_template_two_verified_badge_color!=''){
    $echo_template_two_verified_badge_color = '';
    $echo_template_two_verified_badge_color .='color:'.$rvx_template_two_verified_badge_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .rx_varified .rx_varified_user',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_verified_badge_color)),
    ) );		
}

if($rvx_template_two_verified_badge_icon_color!=''){
    $echo_template_two_verified_badge_icon_color = '';
    $echo_template_two_verified_badge_icon_color .='fill:'.$rvx_template_two_verified_badge_icon_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .rx_varified .rx_varified_user svg .st0',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_verified_badge_icon_color)),
    ) );		
}

if($rvx_template_two_helpful_text_color!=''){
    $echo_template_two_helpful_text_color = '';
    $echo_template_two_helpful_text_color .='color:'.$rvx_template_two_helpful_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .rx_meta .rx_review_vote_icon p',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_helpful_text_color)),
    ) );		
}

if($rvx_template_two_helpful_button_color!=''){
    $echo_template_two_helpful_button_color = '';
    $echo_template_two_helpful_button_color .='background-color:'.$rvx_template_two_helpful_button_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_vote_icon .like',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_helpful_button_color)),
    ) );		
}

if($rvx_template_two_helpful_thumbsup_color!=''){
    $echo_template_two_helpful_thumbsup_color = '';
    $echo_template_two_helpful_thumbsup_color .='fill:'.$rvx_template_two_helpful_thumbsup_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_helpful_style_2_svg svg',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_helpful_thumbsup_color)),
    ) );		
}

if($rvx_template_two_helpful_thumbsup_count_color!=''){
    $echo_template_two_helpful_thumbsup_count_color = '';
    $echo_template_two_helpful_thumbsup_count_color .='fill:'.$rvx_template_two_helpful_thumbsup_count_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_vote_icon .like .rx_helpful_count_val',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_helpful_thumbsup_count_color)),
    ) );		
}

if($rvx_template_two_share_text_color!=''){
    $echo_template_two_share_text_color = '';
    $echo_template_two_share_text_color .='color:'.$rvx_template_two_share_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .rx_meta .rx_share p.rx_share p',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_share_text_color)),
    ) );		
}

if($rvx_template_two_share_icon_color!=''){
    $echo_template_two_share_icon_color = '';
    $echo_template_two_share_icon_color .='fill:'.$rvx_template_two_share_icon_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .social-links .wc_rx_btns ul li:nth-child(1) svg',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_share_icon_color)),
    ) );		
}

if($rvx_template_two_facebook_icon_color!=''){
    $echo_template_two_facebook_icon_color = '';
    $echo_template_two_facebook_icon_color .='fill:'.$rvx_template_two_facebook_icon_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .social-links .wc_rx_btns ul li:nth-child(2) a svg .st0',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_facebook_icon_color)),
    ) );		
}

if($rvx_template_two_twitter_icon_color!=''){
    $echo_template_two_twitter_icon_color = '';
    $echo_template_two_twitter_icon_color .='fill:'.$rvx_template_two_twitter_icon_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .social-links .wc_rx_btns ul li:nth-child(3) a svg .st0',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_twitter_icon_color)),
    ) );		
}

if($rvx_template_two_background_color!=''){
    $echo_template_two_background_colo = '';
    $echo_template_two_background_colo .='background-color:'.$rvx_template_two_background_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_background_colo)),
    ) );		
}

if($rvx_template_two_highlight_icon_color!=''){
    $echo_template_two_highlight_icon_color = '';
    $echo_template_two_highlight_icon_color .='fill:'.$rvx_template_two_highlight_icon_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_admin_heighlights span svg',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_highlight_icon_color)),
    ) );		
}

if($rvx_template_two_highlight_bg_color!=''){
    $echo_template_two_highlight_bg_color = '';
    $echo_template_two_highlight_bg_color .='background-color:'.$rvx_template_two_highlight_bg_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .reviewx_highlight_comment',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_highlight_bg_color)),
    ) );		
}

if($rvx_template_two_reply_highlight_bg_color!=''){
    $echo_template_two_reply_highlight_bg_color = '';
    $echo_template_two_reply_highlight_bg_color .='background-color:'.$rvx_template_two_reply_highlight_bg_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2.rx_listing_filter_style_2 .reviewx_highlight_comment .children, .rx_listing_style_2 .reviewx_highlight_comment .children .rx_review_block',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_reply_highlight_bg_color)),
    ) );		
}

/********************************************
 * 
 * Template two Pagination
 * 
 *******************************************/

if($rvx_template_two_pagination_text_color!=''){
    $echo_template_two_pagination_text_color = '';
    $echo_template_two_pagination_text_color .='color:'.$rvx_template_two_pagination_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx_pagination a',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_pagination_text_color)),
    ) );		
}

if($rvx_template_two_pagination_bg_color!=''){
    $echo_template_two_pagination_bg_color = '';
    $echo_template_two_pagination_bg_color .='background-color:'.$rvx_template_two_pagination_bg_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx_pagination a',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_pagination_bg_color)),
    ) );		
}

if($rvx_template_two_pagination_active_color!=''){
    $echo_template_two_pagination_active_color = '';
    $echo_template_two_pagination_active_color .='color:'.$rvx_template_two_pagination_active_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx_pagination a.current',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_pagination_active_color)),
    ) );		
}

if($rvx_template_two_pagination_active_bg_color!=''){
    $echo_template_two_pagination_active_bg_color = '';
    $echo_template_two_pagination_active_bg_color .='background-color:'.$rvx_template_two_pagination_active_bg_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx_pagination a.current',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_pagination_active_bg_color)),
    ) );		
}

if($rvx_template_two_pagination_hover_text_color!=''){
    $echo_template_two_pagination_hover_text_color = '';
    $echo_template_two_pagination_hover_text_color .='color:'.$rvx_template_two_pagination_hover_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx_pagination a:hover',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_pagination_hover_text_color)),
    ) );		
}

if($rvx_template_two_pagination_hover_bg_color!=''){
    $echo_template_two_pagination_hover_bg_color = '';
    $echo_template_two_pagination_hover_bg_color .='background-color:'.$rvx_template_two_pagination_hover_bg_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx_pagination a:hover',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_pagination_hover_bg_color)),
    ) );		
}

if($rvx_template_two_store_logo_color!=''){
    $echo_template_two_store_logo_color = '';
    $echo_template_two_store_logo_color .='fill:'.$rvx_template_two_store_logo_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .children .rx_thumb svg .st0',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_logo_color)),
    ) );		
}

if($rvx_template_two_store_logo_bg_color!=''){
    $echo_template_two_store_logo_bg_color = '';
    $echo_template_two_store_logo_bg_color .='background-color:'.$rvx_template_two_store_logo_bg_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .children .rx_thumb',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_logo_bg_color)),
    ) );		
}

if($rvx_template_two_store_logo_border_radius!=''){
    $echo_template_two_store_logo_border_radius = '';
    $echo_template_two_store_logo_border_radius .='border-radius:'.$rvx_template_two_store_logo_border_radius.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .children .rx_thumb',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_logo_border_radius)),
    ) );		
}

if($rvx_template_two_store_name_color!=''){
    $echo_template_two_store_name_color = '';
    $echo_template_two_store_name_color .='color:'.$rvx_template_two_store_name_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .children .review_title',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_name_color)),
    ) );		
}

if($rvx_template_two_store_reply_back_icon_color!=''){
    $echo_template_two_store_reply_back_icon_color = '';
    $echo_template_two_store_reply_back_icon_color .='fill:'.$rvx_template_two_store_reply_back_icon_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .children .owner_arrow svg .st0',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_back_icon_color)),
    ) );		
}

if($rvx_template_two_store_reply_text_color!=''){
    $echo_template_two_store_reply_text_color = '';
    $echo_template_two_store_reply_text_color .='color:'.$rvx_template_two_store_reply_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .children .comment-content p',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_text_color)),
    ) );		
}

if($rvx_template_two_store_reply_date_color!=''){
    $echo_template_two_store_reply_date_color = '';
    $echo_template_two_store_reply_date_color .='color:'.$rvx_template_two_store_reply_date_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .children .rx_review_calender',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_date_color)),
    ) );		
}

if($rvx_template_two_store_reply_date_icon_color!=''){
    $echo_template_two_store_reply_date_icon_color = '';
    $echo_template_two_store_reply_date_icon_color .='fill:'.$rvx_template_two_store_reply_date_icon_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .rx_review_calender svg .st0',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_date_icon_color)),
    ) );		
}

if($rvx_template_two_store_reply_date_edit_icon_color!=''){
    $echo_template_two_store_reply_date_edit_icon_color = '';
    $echo_template_two_store_reply_date_edit_icon_color .='fill:'.$rvx_template_two_store_reply_date_edit_icon_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.admin-reply-edit-icon svg',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_date_edit_icon_color)),
    ) );		
}

if($rvx_template_two_store_reply_date_delete_icon_color!=''){
    $echo_template_two_store_reply_date_delete_icon_color = '';
    $echo_template_two_store_reply_date_delete_icon_color .='fill:'.$rvx_template_two_store_reply_date_delete_icon_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.admin-reply-delete-icon svg',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_date_delete_icon_color)),
    ) );		
}

if($rvx_template_two_store_reply_button_text_color!=''){
    $echo_template_two_store_reply_button_text_color = '';
    $echo_template_two_store_reply_button_text_color .='color:'.$rvx_template_two_store_reply_button_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .rx_meta .rx-admin-reply',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_button_text_color)),
    ) );		
}

if($rvx_template_two_store_reply_button_bg_color!=''){
    $echo_template_two_store_reply_button_bg_color = '';
    $echo_template_two_store_reply_button_bg_color .='background-color:'.$rvx_template_two_store_reply_button_bg_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .rx_meta .rx-admin-reply',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_button_bg_color)),
    ) );		
}

if($rvx_template_two_store_reply_button_border_color!=''){
    $echo_template_two_store_reply_button_border_color = '';
    $echo_template_two_store_reply_button_border_color .='border-color:'.$rvx_template_two_store_reply_button_border_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_style_2 .rx_review_block .rx_body .rx_meta .rx-admin-reply',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_button_border_color)),
    ) );		
}

if($rvx_template_two_store_reply_form_bgcolor!=''){
    $echo_template_two_store_reply_form_bgcolor = '';
    $echo_template_two_store_reply_form_bgcolor .='background-color:'.$rvx_template_two_store_reply_form_bgcolor.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx-admin-edit-reply-area, .rx_listing_container_style_2 .rx_review_block .rx_body .rx-admin-reply-area',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_form_bgcolor)),
    ) );		
}

if($rvx_template_two_store_reply_form_border_color!=''){
    $echo_template_two_store_reply_form_border_color = '';
    $echo_template_two_store_reply_form_border_color .='border-color:'.$rvx_template_two_store_reply_form_border_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx-admin-edit-reply-area, .rx_listing_container_style_2 .rx_review_block .rx_body .rx-admin-reply-area',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_form_border_color)),
    ) );		
}

if($rvx_template_two_store_reply_form_border_radius!=''){
    $echo_template_two_store_reply_form_border_radius = '';
    $echo_template_two_store_reply_form_border_radius .='border-radius:'.$rvx_template_two_store_reply_form_border_radius.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx-admin-edit-reply-area, .rx_listing_container_style_2 .rx_review_block .rx_body .rx-admin-reply-area',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_form_border_radius)),
    ) );		
}

if($rvx_template_two_store_reply_form_title_color!=''){
    $echo_template_two_store_reply_form_title_color = '';
    $echo_template_two_store_reply_form_title_color .='color:'.$rvx_template_two_store_reply_form_title_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx_review_block .rx_body .rx-admin-reply-area .admin-reply-form-title,
        .rx_listing_container_style_2 .rx-admin-edit-reply-area .admin-reply-form-title',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_form_title_color)),
    ) );		
}

if($rvx_template_two_store_reply_form_textarea_bgcolor!=''){
    $echo_template_two_store_reply_form_textarea_bgcolor = '';
    $echo_template_two_store_reply_form_textarea_bgcolor .='background-color:'.$rvx_template_two_store_reply_form_textarea_bgcolor.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx_review_block .rx_body .rx-admin-reply-area .comment-form-comment .rx-admin-reply-text, 
        .rx_listing_container_style_2 .rx-admin-edit-reply-area .comment-form-comment .rx-admin-reply-text',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_form_textarea_bgcolor)),
    ) );		
}

if($rvx_template_two_store_reply_form_button_color!=''){
    $echo_template_two_store_reply_form_button_color = '';
    $echo_template_two_store_reply_form_button_color .='background-color:'.$rvx_template_two_store_reply_form_button_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx-admin-edit-reply-area .form-submit .admin-review-edit-reply, 
        .rx_listing_container_style_2 .rx_review_block .rx_body .rx-admin-reply-area .form-submit .admin-review-reply',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_form_button_color)),
    ) );		
}

if($rvx_template_two_store_reply_form_button_text_color!=''){
    $echo_template_two_store_reply_form_button_text_color = '';
    $echo_template_two_store_reply_form_button_text_color .='color:'.$rvx_template_two_store_reply_form_button_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx-admin-edit-reply-area .form-submit .admin-review-edit-reply, 
        .rx_listing_container_style_2 .rx_review_block .rx_body .rx-admin-reply-area .form-submit .admin-review-reply',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_form_button_text_color)),
    ) );		
}

if($rvx_template_two_store_reply_form_cancel_button_bg_color!=''){
    $echo_template_two_store_reply_form_cancel_button_bg_color = '';
    $echo_template_two_store_reply_form_cancel_button_bg_color .='background-color:'.$rvx_template_two_store_reply_form_cancel_button_bg_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx-admin-edit-reply-area .form-submit .cancel-admin-edit-reply, .rx_review_block .rx_body .rx-admin-reply-area .form-submit .cancel-admin-reply',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_form_cancel_button_bg_color)),
    ) );		
}

if($rvx_template_two_store_reply_form_cancel_button_border_color!=''){
    $echo_template_two_store_reply_form_cancel_button_border_color = '';
    $echo_template_two_store_reply_form_cancel_button_border_color .='border-color:'.$rvx_template_two_store_reply_form_cancel_button_border_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx-admin-edit-reply-area .form-submit .cancel-admin-edit-reply, .rx_review_block .rx_body .rx-admin-reply-area .form-submit .cancel-admin-reply',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_form_cancel_button_border_color)),
    ) );		
}

if($rvx_template_two_store_reply_form_cancel_button_text_color!=''){
    $echo_template_two_store_reply_form_cancel_button_text_color = '';
    $echo_template_two_store_reply_form_cancel_button_text_color .='color:'.$rvx_template_two_store_reply_form_cancel_button_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx_listing_container_style_2 .rx-admin-edit-reply-area .form-submit .cancel-admin-edit-reply, .rx_review_block .rx_body .rx-admin-reply-area .form-submit .cancel-admin-reply',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_store_reply_form_cancel_button_text_color)),
    ) );		
}

//Review Form
if($rvx_template_two_form_criteria_color!=''){
    $echo_template_two_form_criteria_color = '';
    $echo_template_two_form_criteria_color .='color:'.$rvx_template_two_form_criteria_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-review-form-area-style-2 .rx-criteria-table td',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_form_criteria_color)),
    ) );		
}

if( $rvx_template_two_form_rating_color != '' ){
    $echo_template_two_form_icon_fill_color = '';
    $echo_template_two_form_icon_fill_color .='fill:'.$rvx_template_two_form_rating_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-review-form-area-style-2 .rx_star_rating > input:checked ~ label .icon-star,
        .rx-review-form-area-style-2 .reviewx-thumbs-rating input[type="radio"]:checked + label svg, .rx-review-form-area-style-2 .reviewx-thumbs-rating input[type="radio"]:checked + label svg #rx_dislike path,
        .rx-review-form-area-style-2 .reviewx-face-rating fieldset input[type="radio"]:checked + label .happy_st0, .rx-review-form-area-style-2 .reviewx-face-rating fieldset input[type="radio"]:checked + label .st1',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_form_icon_fill_color)),
    ) );

    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-review-form-area-style-2 .rx_star_rating:not(:checked) > label:hover .icon-star, .rx-review-form-area-style-2 .rx_star_rating:not(:checked) > label:hover ~ label .icon-star',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_form_icon_fill_color)),
    ) );    
    
    $echo_template_two_form_icon_stroke_color = '';
    $echo_template_two_form_icon_stroke_color .='stroke:'.$rvx_template_two_form_rating_color.'!important;';
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-review-form-area-style-2 .rx_star_rating .icon-star,
        .rx-review-form-area-style-2 .rx_star_rating:not(:checked) > label:hover .icon-star, .rx_star_rating:not(:checked) > label:hover ~ label .icon-star',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_form_icon_stroke_color)),
    ) );
    
}

if($rvx_template_two_form_recommendation_label_color!=''){
    $echo_template_two_form_recommendation_label_color = '';
    $echo_template_two_form_recommendation_label_color .='color:'.$rvx_template_two_form_recommendation_label_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.reviewx_recommended_title ',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_form_recommendation_label_color)),
    ) );		
}

if($rvx_template_two_form_icon_active_color!=''){
    $echo_template_two_form_icon_active_color = '';
    $echo_template_two_form_icon_active_color .='fill:'.$rvx_template_two_form_icon_active_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-review-form-area-style-2 .reviewx_recommended_list .reviewx_radio input[type="radio"]:checked + .radio-label svg .rx_happy, .rx-review-form-area-style-2 .reviewx_recommended_list .reviewx_radio input[type="radio"]:checked + .radio-label svg .st1',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_form_icon_active_color)),
    ) );		
}

if($rvx_template_two_form_external_video_link_color!=''){
    $echo_template_two_form_external_video_link_color = '';
    $echo_template_two_form_external_video_link_color .='color:'.$rvx_template_two_form_external_video_link_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-review-form-area-style-2 #review_form .rx-note-video',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_form_external_video_link_color)),
    ) );		
}

if($rvx_template_two_form_submit_button_text_color!=''){
    $echo_template_two_form_submit_button_text_color = '';
    $echo_template_two_form_submit_button_text_color .='color:'.$rvx_template_two_form_submit_button_text_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-review-form-area-style-2 #review_form input[type="submit"], 
        .rx-review-form-area-style-2 #review_form input[type="submit"]:focus',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_form_submit_button_text_color)),
    ) );		
}

if($rvx_template_two_form_submit_button_bg_color!=''){
    $echo_template_two_form_submit_button_bg_color = '';
    $echo_template_two_form_submit_button_bg_color .='background-color:'.$rvx_template_two_form_submit_button_bg_color.'!important;';
    $echo_template_two_form_submit_button_bg_color .='border-color:'.$rvx_template_two_form_submit_button_bg_color.'!important;';
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-review-form-area-style-2 #review_form input[type="submit"], 
         .rx-review-form-area-style-2 #review_form input[type="submit"]:focus',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_form_submit_button_bg_color)),
    ) );		
}

if($rvx_template_two_form_submit_button_border_radius!=''){
    $echo_template_two_form_submit_button_border_radius = '';
    $echo_template_two_form_submit_button_border_radius .='border-radius:'.$rvx_template_two_form_submit_button_border_radius.'!important;';    
        
    ET_Builder_Element::set_style( 'et_pb_wc_review_for_ReviewX', array(
        'selector'    => '.rx-review-form-area-style-2 #respond input#submit',
        'declaration' => sprintf('%1$s',esc_attr($echo_template_two_form_submit_button_border_radius)),
    ) );		
}